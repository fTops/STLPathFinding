#include "stdafx.h"
#include "OpenSet.h"

OpenSet::OpenSet() {}

OpenSet::~OpenSet() {
	std::vector<Node *>::const_iterator it;
	it = m_set.begin();
	
	while (it != m_set.end()) {
		Node *ptr = *it;
		delete ptr;
		++it;
	}
}

void OpenSet::addToSet(Node *node) {
	m_set.push_back(node);
}

bool OpenSet::isSetEmpty() const {
	return m_set.empty();
}

Node* OpenSet::findNodeWithMinFCost(int &curIndex, int &curX, int &curY, int &curGCost) const {
	std::vector<Node *>::const_iterator it;
	it = m_set.begin();

	int minCost = m_set.at(0)->m_fCost;

	Node *ptr;
	Node *ptr2 = *it;

	int index = 0;

	curIndex = 0;

	while (it != m_set.end()) {

		ptr = *it;

		if (ptr->m_fCost < minCost) {
			ptr2 = *it;
			minCost = ptr->m_fCost;
			curIndex = index;
		}

		++it;
		++index;
	}

	curX = ptr2->m_X;
	curY = ptr2->m_Y;
	curGCost = minCost;

	return ptr2;
}

void OpenSet::removeANode(const int current) {
	m_set.erase(m_set.begin() + current);
}

Node* OpenSet::existsInSet(const int neighborX, const int neighborY, int &returnNeighborGCost) const {
	std::vector<Node *>::const_iterator it;
	it = m_set.begin();

	while (it != m_set.end()) {

		Node *ptr;
		ptr = *it;

		if ((ptr->m_X == neighborX) && (ptr->m_Y == neighborY)) {
			returnNeighborGCost = ptr->m_gCost;
			return ptr;
		}
		++it;
	}

	return nullptr;
}
