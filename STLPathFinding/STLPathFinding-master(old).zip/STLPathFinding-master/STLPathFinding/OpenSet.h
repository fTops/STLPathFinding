#pragma once
#include <vector>
#include "Node.h"

class OpenSet {
	std::vector<Node *> m_set;

public:
	OpenSet();
	~OpenSet();

	void addToSet(Node *node);
	bool isSetEmpty() const;
	Node* findNodeWithMinFCost(int &curIndex, int &curX, int &curY, int &curGCost) const;
	void removeANode(const int current);
	Node* existsInSet(const int neighborX, const int neighborY, int &returnNeighborGCost) const;
};