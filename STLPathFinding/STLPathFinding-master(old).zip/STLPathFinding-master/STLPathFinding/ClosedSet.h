#pragma once
#include <deque>
#include "Node.h"

class ClosedSet {
	std::deque<Node *> m_set;

public:
	ClosedSet();
	~ClosedSet();

	void addToSet(Node *node);
	Node* existsInSet(const int neighborX, const int neighborY, int &returnNeighborGCost) const;
	int reconstructPath(const int nTargetX, const int nTargetY, const int nMapWidth, int *pOutBuffer, const int nOutBufferSize);
};

int convert2DTo1D(const int x, const int y, const int nMapWidth);
