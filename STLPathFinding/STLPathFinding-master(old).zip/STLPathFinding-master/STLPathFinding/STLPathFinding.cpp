#include "stdafx.h"
#include <iostream>
#include <sstream>
#include <algorithm>
#include "OpenSet.h"
#include "ClosedSet.h"

int FindPath(const int nStartX, const int nStartY, const int nTargetX, const int nTargetY,
	const unsigned char* pMap, const int nMapWidth, const int nMapHeight,
	int* pOutBuffer, const int nOutBufferSize);

void putDiscoveredNodeInOpenSet(int curX, int curY, int curGCost,
	int discoveredNodeX, int discoveredNodeY, int nTargetX, int nTargetY,
	OpenSet &openSet, ClosedSet &closedSet) {

	int discoveredNodeGCost = 0;

	if (!closedSet.existsInSet(discoveredNodeX, discoveredNodeY, discoveredNodeGCost)) {

		const int tempGCost = curGCost + 1;

		Node *found;
		found = openSet.existsInSet(discoveredNodeX, discoveredNodeY, discoveredNodeGCost);

		if (!found) {
			Node *pos = new Node{ discoveredNodeX, discoveredNodeY, curX, curY, nTargetX, nTargetY, curGCost };
			openSet.addToSet(pos);
		}
		else {
			if (tempGCost < discoveredNodeGCost) {
				found->updateNode(curX, curY, tempGCost);
			}
		}
	}
}

char validateYNInput(std::string input) {

	transform(input.begin(), input.end(), input.begin(), toupper); // make input to all CAPS

	if (input == "Y" || input == "YES")
		return 'Y';
	else if (input == "N" || input == "NO")
		return 'N';

	std::cout << "\nInvalid input, please try again\n\n";
	return 'F';
}

int main() {
	unsigned char pMap[] = { 1, 1, 1, 1,
		0, 1, 0, 1,
		0, 1, 1, 1 };

	const int nMapWidth = 4;
	const int nMapHeight = 3;

	const int nStartX = 0;
	const int nStartY = 0;
	const int nTargetX = 1;
	const int nTargetY = 2;

	int *pOutBuffer = nullptr;

	int nOutBufferSize = 3;

	while (true) {

		pOutBuffer = new int[nOutBufferSize];

		int result;

		if (nMapWidth >= 1 && nMapHeight >= 1 && nStartX >= 0 && nStartX < nMapWidth && nStartY >= 0 && nStartY < nMapHeight &&
			nTargetX >= 0 && nTargetX < nMapWidth && nTargetY >= 0 && nTargetY < nMapHeight &&
			pMap[convert2DTo1D(nStartX, nStartY, nMapWidth)] == 1 && pMap[convert2DTo1D(nTargetX, nTargetY, nMapWidth)] == 1
			&& nOutBufferSize >= 0) {

			result = FindPath(nStartX, nStartY, nTargetX, nTargetY, pMap, nMapWidth, nMapHeight, pOutBuffer, nOutBufferSize);
		}
		else {
			std::cout << "One or more of the parameters do not fit the constraints, change them and run it again.\n";
			delete[] pOutBuffer;
			return -2;
		}

		if (result == -1) {
			std::cout << "No path exists between (" << nStartX << "," << nStartY << ") and (" << nTargetX << "," << nTargetY << ")\n";
			delete[] pOutBuffer;
			return -1;
		}
		else if (result == -2) {
			std::cout << "The buffer size is too small to fit the complete path.\n";

			std::string input;
			int choice;

			do {
				std::cout << "Do you want to increase the size and try again? (Y / N): ";
				std::getline(std::cin, input);
				choice = validateYNInput(input);
			} while (choice == 'F'); // F for failure, if the user selected anything other than Yes or No

			if (choice == 'Y') {
				while (true) {

					std::cout << "Enter the new buffer size (bigger than " << nOutBufferSize << "): ";
					std::getline(std::cin, input);
					std::stringstream myStream(input);
					int bufferSize;

					if (myStream >> bufferSize)
						if (bufferSize <= nOutBufferSize)
							continue;
						else {
							delete[] pOutBuffer;
							pOutBuffer = nullptr;
							nOutBufferSize = bufferSize;
							break;
						}

				}
				continue;
			}
			else {
				delete[] pOutBuffer;
				return 0;
			}
		}
		else {
			std::cout << "The length of the shortest path between (" << nStartX << ", " << nStartY << ") and (" << nTargetX << ", " << nTargetY << ") is: " << result << std::endl;
			std::cout << "The path itself is:\n";

			for (int i = 0; i < result; ++i) {
				std::cout << pOutBuffer[i];
				if (i != result - 1)
					std::cout << " -> ";
				else
					std::cout << std::endl;
			}
			delete[] pOutBuffer;
			return 0;
		}
	}
}

int FindPath(const int nStartX, const int nStartY, const int nTargetX, const int nTargetY,
	const unsigned char* pMap, const int nMapWidth, const int nMapHeight,
	int* pOutBuffer, const int nOutBufferSize) {

	ClosedSet closedSet;
	OpenSet openSet;

	Node *start = new Node{ nStartX, nStartY, nStartX, nStartY, nTargetX, nTargetY, -1 };
	openSet.addToSet(start);

	int curIndex;
	int curX;
	int curY;
	int curGCost;
	Node *current;

	while (!openSet.isSetEmpty()) {

		current = openSet.findNodeWithMinFCost(curIndex, curX, curY, curGCost);

		if (curX == nTargetX && curY == nTargetY) {
			closedSet.addToSet(current);
			openSet.removeANode(curIndex);
			return closedSet.reconstructPath(nTargetX, nTargetY, nMapWidth, pOutBuffer, nOutBufferSize);
		}

		closedSet.addToSet(current);
		openSet.removeANode(curIndex);

		if (curY > 0)
			if (pMap[convert2DTo1D(curX, curY, nMapWidth) - nMapWidth] == 1)
				putDiscoveredNodeInOpenSet(curX, curY, curGCost, curX, curY - 1, nTargetX, nTargetY, openSet, closedSet);

		if (curY < nMapHeight - 1)
			if (pMap[convert2DTo1D(curX, curY, nMapWidth) + nMapWidth] == 1)
				putDiscoveredNodeInOpenSet(curX, curY, curGCost, curX, curY + 1, nTargetX, nTargetY, openSet, closedSet);

		if (curX > 0)
			if (pMap[convert2DTo1D(curX, curY, nMapWidth) - 1] == 1)
				putDiscoveredNodeInOpenSet(curX, curY, curGCost, curX - 1, curY, nTargetX, nTargetY, openSet, closedSet);

		if (curX < nMapWidth - 1)
			if (pMap[convert2DTo1D(curX, curY, nMapWidth) + 1] == 1)
				putDiscoveredNodeInOpenSet(curX, curY, curGCost, curX + 1, curY, nTargetX, nTargetY, openSet, closedSet);
	}

	return -1;
}